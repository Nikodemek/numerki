﻿namespace Zadanie5.Model.Polynomials;

public interface IOrthogonalPolynomials
{
    double Get(int k, double x);
}