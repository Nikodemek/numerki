namespace Zadanie3.Dao;

public interface IFileReader<T>
{
    T Read();
}