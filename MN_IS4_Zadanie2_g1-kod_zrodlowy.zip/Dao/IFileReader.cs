namespace Zadanie2.Dao;

public interface IFileReader<T>
{
    T Read();
}